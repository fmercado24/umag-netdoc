PLANTILLA LATEX - PROYECTO DE TÍTULO
Departamento de Ingeniería en Computación - Universidad de Magallanes

Archivos:
- main.tex: plantilla principal.
- referencias.bib: ejemplos de referencias bibliográficas.

Compilación recomendada:
1. pdflatex main.tex
2. biber main
3. pdflatex main.tex
4. pdflatex main.tex

También puede utilizar Overleaf:
- Crear un proyecto nuevo.
- Subir main.tex y referencias.bib.
- Seleccionar pdfLaTeX como compilador.

Antes de comenzar:
Edite en main.tex las variables:
\TituloTrabajo
\NombreEstudiante
\TituloProfesional
\ProfesorGuia
\DirectorDepartamento
\AnioPresentacion
\FechaEvaluacion

La plantilla considera:
- Papel carta.
- Margen izquierdo e inferior de 3 cm.
- Margen derecho de 2 cm.
- Interlineado 1,5.
- Fuente equivalente a Times New Roman, tamaño 12.
- Numeración romana para Resumen/Índice.
- Numeración arábiga para el cuerpo del trabajo.
- Número de página en la esquina superior derecha.
- Páginas separadoras de capítulo sin numeración.
- Numeración de figuras, tablas y ecuaciones por capítulo.
- Anexos identificados alfabéticamente.
